'''
  package __init__
'''
# bring up the goods into main namespace
from text_util import *
